﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Newtonsoft.Json;

namespace C_Practice
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 1
            /*List<int> ints = new List<int>();

            Console.Write("Enter integer array (',' for separation): ");
            string readedFromKeyboard = Console.ReadLine();

            foreach (string c in readedFromKeyboard.Split(','))
            {
                ints.Add(int.Parse(c));
            }

            string serializedList = JsonConvert.SerializeObject(ints);

            using (StreamWriter writer = new StreamWriter("SerializedInts.json"))
            {
                writer.WriteLine(serializedList);
            }

            using (StreamReader reader = new StreamReader("SerializedInts.json"))
            {
                List<int> loadedInts = JsonConvert.DeserializeObject<List<int>>(reader.ReadToEnd());

                Console.Write("Loaded list: ");
                foreach (int i in loadedInts) Console.Write(i + ", ");
                Console.WriteLine();
            }*/

            // 2, 3, 4
            List<MusicAlbum> musicAlbums = new List<MusicAlbum>();

            Console.Write("Enter album mode (0 - create albums, 1 - load albums from file): ");
            int mode = int.Parse(Console.ReadLine());

            switch (mode)
            {
                case 0:
                    for (int i = 0; i < 3; i++)
                    {
                        Console.WriteLine("Album #1");

                        Console.Write("Enter album name: ");
                        string albumName = Console.ReadLine();

                        Console.Write("Enter album author: ");
                        string albumAuthor = Console.ReadLine();

                        Console.Write("Enter album year of release: ");
                        int albumYear = int.Parse(Console.ReadLine());

                        Console.Write("Enter time length: ");
                        float albumTimeLength = float.Parse(Console.ReadLine());

                        Console.Write("Enter album studio: ");
                        string albumStudio = Console.ReadLine();

                        List<Song> songs = new List<Song>();

                        for (int j = 0; j < 3; j++)
                        {
                            Console.Write("\tEnter song name: ");
                            string songName = Console.ReadLine();

                            Console.Write("Enter song time length: ");
                            float songTimeLength = float.Parse(Console.ReadLine());

                            Console.Write("Enter song style: ");
                            string songStyle = Console.ReadLine();

                            songs.Add(new Song(songName, songTimeLength, songStyle));
                        }

                        musicAlbums.Add(new MusicAlbum(albumName, albumAuthor, albumYear, albumTimeLength, albumStudio) { Songs = songs });
                    }

                    using (StreamWriter writer = new StreamWriter("MusicAlbums.json"))
                    {
                        string serializedAlbums = JsonConvert.SerializeObject(musicAlbums, Formatting.Indented);
                        writer.Write(serializedAlbums);
                    }
                    break;
                default:
                    if (!File.Exists("MusicAlbums.json"))
                    {
                        Console.WriteLine("File with albums does not exists!");
                        return;
                    }

                    using (StreamReader reader = new StreamReader("MusicAlbums.json"))
                    {
                        musicAlbums = JsonConvert.DeserializeObject<List<MusicAlbum>>(reader.ReadToEnd());

                        foreach (MusicAlbum album in musicAlbums)
                        {
                            Console.WriteLine("========");
                            Console.WriteLine(album);
                        }
                    }
                    break;
            }


            Console.ReadKey();
        }
    }
}
