﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Practice
{
    internal class Song
    {
        public string Name { get; set; }
        public double TimeLength { get; set; }
        public string Style { get; set; }

        public Song(string name, double timeLength, string style)
        {
            Name = name;
            TimeLength = timeLength;
            Style = style;
        }

        public override string ToString()
        {
            return $"Song '{Name}' in {Style} style - {TimeLength}";
        }
    }
}
