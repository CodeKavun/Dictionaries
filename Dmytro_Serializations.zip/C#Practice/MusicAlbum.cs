﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Practice
{
    internal class MusicAlbum
    {
        public string Name { get; set; }
        public string Author { get; set; }
        public int Year { get; set; }
        public float TimeLength { get; set; }
        public string RecordingStudio { get; set; }

        public List<Song> Songs { get; set; }

        public MusicAlbum(string name, string author, int year, float timeLength, string recordingStudio)
        {
            Name = name;
            Author = author;
            Year = year;
            TimeLength = timeLength;
            RecordingStudio = recordingStudio;
        }

        public override string ToString()
        {
            string fullName = $"Album '{Name}' by {Author} of year {Year}, recorded by {RecordingStudio} - {TimeLength}\n Songs:";
            foreach (Song song in Songs) fullName += "\n\t" + song.ToString();

            return fullName;
        }
    }
}
