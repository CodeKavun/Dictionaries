﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace C_Practice
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();

            // 1
            Console.WriteLine("===1===");

            using (StreamWriter writer = new StreamWriter("numbers.txt"))
            {
                for (int i = 0; i < 8; i++)
                {
                    writer.Write(random.Next(0, 9));
                }
            }

            using (StreamReader reader = new StreamReader("numbers.txt"))
            {
                foreach (char num in reader.ReadLine())
                {
                    Console.WriteLine(int.Parse(num.ToString()) % 2 == 0 ? "is even" : "is odd");
                }
            }

            // 2
            Console.WriteLine("\n===2===");

            List<string> awesomeList = new List<string>();

            for (int i = 0; i < 3; i++)
            {
                Console.Write($"Enter some awesome thing #{i + 1}: ");
                string awesomeThing = Console.ReadLine();
                awesomeList.Add(awesomeThing);
            }

            using (StreamWriter writer = new StreamWriter("someAwesomeThing.txt"))
            {
                foreach (string awesomeThing in awesomeList)
                {
                    writer.WriteLine(awesomeThing);
                }
            }

            // 3
            Console.WriteLine("\n===3===");
            List<string> loadedList = new List<string>();

            using (StreamReader reader = new StreamReader("someAwesomeThing.txt"))
            {
                foreach (string awesomeThing in reader.ReadToEnd().Split('\n'))
                {
                    loadedList.Add(awesomeThing);
                }
                loadedList.Remove(loadedList.Last());
            }

            foreach (string awesomeThing in loadedList) Console.WriteLine(" - " + awesomeThing);

            // 4
            Console.WriteLine("\n===4===");

            List<int> randomAwfulNumbers = new List<int>();
            for (int i = 0; i < 10_000; i++) randomAwfulNumbers.Add(random.Next(-1000, 1000));

            using (StreamWriter writer = new StreamWriter("evenNumbers.txt"))
            {
                foreach (int num in randomAwfulNumbers)
                {
                    if (num % 2 == 0) writer.WriteLine(num);
                }
            }

            using (StreamWriter writer = new StreamWriter("oddNumbers.txt"))
            {
                foreach (int num in randomAwfulNumbers)
                {
                    if (num % 2 != 0) writer.WriteLine(num);
                }
            }

            Console.WriteLine($"Even numbers = {GetNumberCountFromFile("evenNumbers.txt")}");
            Console.WriteLine($"Odd numbers = {GetNumberCountFromFile("oddNumbers.txt")}");

            // 5
            Console.WriteLine("\n===5===");
            using (StreamWriter writer = new StreamWriter("SomeAwfulSentence.txt", false, Encoding.UTF8))
            {
                writer.WriteLine("Dzisiaj biedni maturzysty męczą się z maturą...");
            }

            Console.Write("Enter finding mode (0 - find if word is in file; 1 - word amount; 2 - like 1 but reversed): ");
            int mode = int.Parse(Console.ReadLine());

            Console.Write("Enter a word for finding: ");
            string word = Console.ReadLine(); // Консоль чомусь не розуміє польські літери

            switch (mode)
            {
                case 1:
                    Console.WriteLine(FindWordAmountInFile("SomeAwfulSentence.txt", word));
                    break;
                case 2:
                    Console.WriteLine(FindWordReversedInFile("SomeAwfulSentence.txt", word));
                    break;
                default:
                    Console.WriteLine(FindIfWordIsInFile("SomeAwfulSentence.txt", word));
                    break;
            }
        }

        private static int GetNumberCountFromFile(string filename)
        {
            using (StreamReader reader = new StreamReader(filename))
            {
                List<string> numbers = new List<string>();
                foreach (string number in reader.ReadToEnd().Split('\n'))
                    numbers.Add(number);
                numbers.Remove(numbers.Last());

                return numbers.Count();
            }
        }

        private static bool FindIfWordIsInFile(string filename, string word)
        {
            using (StreamReader reader = new StreamReader(filename, Encoding.UTF8))
            {
                string text = reader.ReadToEnd();
                return text.Contains(word);
            }
        }

        private static int FindWordAmountInFile(string filename, string word)
        {
            using (StreamReader reader = new StreamReader(filename, Encoding.UTF8))
            {
                string[] text = reader.ReadToEnd().Replace(",", "").Replace(".", "").Split(' ');

                int wordAmount = 0;
                foreach (string textWord in text)
                {
                    if (textWord == word) wordAmount++;
                }

                return wordAmount;
            }
        }

        private static int FindWordReversedInFile(string filename, string word)
        {
            char[] chars = word.ToCharArray();
            Array.Reverse(chars);
            string reversedWord = new string(chars);

            return FindWordAmountInFile(filename, reversedWord);
        }
    }
}
