﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace C_Practice
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 1
            Console.WriteLine("===1===");
            string[] someCoolStrings = { "Polska", "Ukraine", "IT", "MIT", "Linux", "Windows", "MacOS",
                "C#", "C++", "Python", "JavaScript", "React", "SQL", "Mykola's HTML/CSS annoying qubes :)" };

            string[] sortedCoolStrings;

            Console.Write("Your array sorting by character option (0 - ascending, 1 - descending): ");
            int sortMode = int.Parse(Console.ReadLine());

            switch (sortMode)
            {
                case 0:
                    someCoolStrings = someCoolStrings.OrderBy(str => str).ToArray();
                    sortedCoolStrings = someCoolStrings.OrderBy(str => str.Length).ToArray();
                    break;
                default:
                    someCoolStrings = someCoolStrings.OrderByDescending(str => str).ToArray();
                    sortedCoolStrings = someCoolStrings.OrderByDescending(str => str.Length).ToArray();
                    break;
            }

            PrintList(sortedCoolStrings.ToList(), "\n");

            // 2
            Console.WriteLine("\n===2===");

            int[] numbers1 = { 2, 2, 2, 4, 67, 1, 239, 239, 3957, 23820, 67, 4, 123 };
            int[] numbers2 = { 2, 43, 11, 1, 239, 123, 4069, 67, 69 };

            int[] excepts = numbers1.Except(numbers2).ToArray();
            PrintList(excepts.ToList());

            int[] intersects = numbers1.Intersect(numbers2).ToArray();
            PrintList(intersects.ToList());

            int[] unions = numbers1.Union(numbers2).ToArray();
            PrintList(unions.ToList());

            int[] uniques = numbers1.Distinct().ToArray();
            PrintList(uniques.ToList());

            // 3
            Console.WriteLine("\n===3===");
            List<Car> cars1 = new List<Car>
            {
                new Car("Crossover", "Suzuki", 2020),
                new Car("Ferrari", "Something Italian", 2000),
                new Car("SomeCar #1", "Volvo", 3024),
                new Car("SomeCar #3", "Nissan", 1999)
            };
            List<Car> cars2 = new List<Car>
            {
                new Car("Crossover#1", "Suzuki", 2022),
                new Car("SomeCar #0", "BMW", 2000),
                new Car("SomeCar #1", "Mercedes", 3024),
                new Car("SomeCar #3", "Nissan", 1999)
            };

            List<Car> carExcepts = cars1.Except(cars2, new CarManufacturerComparer()).ToList();
            PrintList(carExcepts, "\n");

            List<Car> carIntersects = cars1.Intersect(cars2, new CarManufacturerComparer()).ToList();
            PrintList(carIntersects, "\n");

            List<Car> carUnions = cars1.Union(cars2, new CarManufacturerComparer()).ToList();
            PrintList(carUnions, "\n");

            Console.ReadKey();
        }

        private static void PrintList<T>(List<T> list, string separator = " ")
        {
            foreach (T item in list) Console.Write(item + separator);
            Console.WriteLine();
        }
    }

    internal class Car
    {
        public string Name { get; set; }
        public string Manufacturer { get; set; }
        public int ReleaseYear { get; set; }

        public Car(string name, string manufacturer, int releaseYear)
        {
            Name = name;
            Manufacturer = manufacturer;
            ReleaseYear = releaseYear;
        }

        public override string ToString()
        {
            return $"  {Name} - {Manufacturer}, {ReleaseYear}";
        }
    }

    class CarManufacturerComparer : IEqualityComparer<Car>
    {
        public bool Equals(Car x, Car y)
        {
            return x.Manufacturer == y.Manufacturer;
        }

        public int GetHashCode(Car obj)
        {
            return obj.Manufacturer.GetHashCode();
        }
    }
}
