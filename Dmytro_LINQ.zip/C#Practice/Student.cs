﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Practice
{
    internal class Student
    {
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public int Age { get; set; }
        public string University { get; set; }

        public Student(string firstName, string lastName, int age, string university)
        {
            Firstname = firstName;
            Lastname = lastName;
            Age = age;
            University = university;
        }

        public override string ToString()
        {
            return $" - {Firstname} {Lastname}, {Age}. {University}";
        }
    }
}
