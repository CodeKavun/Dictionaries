﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace C_Practice
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 1
            Console.WriteLine("===1===");
            List<int> numbers = new List<int> { 2, 5, 9, 3, 5, 4, 4, 7, 21, 6, 9, 10, 456, 123 };

            PrintList(numbers);

            List<int> evenNumbers = numbers.Where(n => n % 2 == 0).ToList();
            PrintList(evenNumbers);

            List<int> oddNumbers = numbers.Where(n => n % 2 != 0).ToList();
            PrintList(oddNumbers);

            List<int> numbersGreaterThan100 = numbers.Where(n => n > 100).ToList();
            PrintList(numbersGreaterThan100);

            List<int> numbersBetween5and10 = numbers.Where(n => n >= 5 && n <= 10).ToList();
            PrintList(numbersBetween5and10);

            List<int> numbersTo7 = numbers.Where(n => n % 7 == 0).ToList();
            PrintList(numbersTo7);
            
            List<int> numbersTo8 = numbers.Where(n => n % 8 == 0).ToList();
            PrintList(numbersTo8);


            // 2
            Console.WriteLine("\n===2===");

            List<string> cities = new List<string> { "Kyiv", "Kherson", "Skadovs'k", "Odesa", "Lviv",
                "Wrocław", "Kraków", "Dresden", "Kryvyj_Rih", "Nova_Kahovka", "Łódź", "Leipzig" };

            PrintList(cities);

            List<string> citiesWithNameLength7 = cities.Where(c => c.Length == 7).ToList();
            PrintList(citiesWithNameLength7);

            List<string> citiesWithLStart = cities.Where(c => c.StartsWith("K")).ToList();
            PrintList(citiesWithLStart);

            List<string> citiesWithWEnding = cities.Where(c => c.EndsWith("w")).ToList();
            PrintList(citiesWithWEnding);

            List<string> startKEndV = cities.Where(c => c.StartsWith("K") && c.EndsWith("v")).ToList();
            PrintList(startKEndV);

            List<string> descStartWithKr = cities.Where(c => c.StartsWith("Kr")).OrderByDescending(name => name).ToList();
            PrintList(descStartWithKr);


            // 3
            Console.WriteLine("\n===3===");
            List<Student> students = new List<Student>
            {
                new Student("Boris", "Jonson", 22, "Oxford"),
                new Student("Boris", "Brown", 25, "MIT"),
                new Student("Elizabet", "Brownie", 19, "MIT"),
                new Student("Rolnik", "Polsko-Szalony", 17, "Oxford"),
                new Student("Dmytro", "Chapny", 17, "MIT"),
                new Student("Someony", "Somewherie", 26, "Oxford")
            };

            PrintList(students, "\n");

            List<Student> borises = students.Where(s => s.Firstname == "Boris").ToList();
            PrintList(borises, "\n");

            List<Student> bros = students.Where(s => s.Lastname.StartsWith("Bro")).ToList();
            PrintList(bros, "\n");

            List<Student> elder19 = students.Where(s => s.Age >= 19).ToList();
            PrintList(elder19, "\n");

            List<Student> elder19Younger23 = students.Where(s => s.Age >= 19 && s.Age <= 23).ToList();
            PrintList(elder19Younger23, "\n");

            List<Student> mitStudents = students.Where(s => s.University == "MIT").ToList();
            PrintList(mitStudents, "\n");

            List<Student> oxfordStudents = students.Where(s => s.University == "Oxford" && s.Age >= 18)
                .OrderByDescending(s => s.Age).ToList();
            PrintList(oxfordStudents, "\n");

            Console.ReadKey();
        }

        private static void PrintList<T>(List<T> list, string separator = " ")
        {
            foreach (T item in list) Console.Write(item + separator);
            Console.WriteLine();
        }
    }
}
